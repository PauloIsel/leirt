package testes.test1;

public class TransactionException extends Exception {
    private final Transaction transaction;

    public TransactionException( ) {
        super("Invalid transaction");
        transaction = null;
    }

    public TransactionException( String msg, Transaction t ) {
        super(msg);
        transaction= t;
    }
    public Transaction getTransaction() {
        return transaction;
    }
}
