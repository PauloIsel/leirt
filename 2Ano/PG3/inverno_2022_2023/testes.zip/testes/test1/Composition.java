package testes.test1;

import java.util.function.Predicate;

public interface Composition extends Iterable<Transaction>{
    boolean find(Predicate<String> pred);
    Composition append(Transaction p ) throws TransactionException;
}
