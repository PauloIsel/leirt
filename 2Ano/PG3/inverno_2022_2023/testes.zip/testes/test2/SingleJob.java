package testes.test2;

import java.time.LocalDate;
import java.util.Objects;

public class SingleJob implements Job {
    private final LocalDate start;
    private final String name;
    private final LocalDate end;
    public SingleJob(String nm, LocalDate start, int days) {
        name=nm;
        this.start= start;
        end= start.plusDays(days-1);
    }
    public SingleJob(String nm, String startDate, int days) {
        this(nm, LocalDate.parse( startDate ), days);
    }
    public SingleJob(String nm, int days) {
        this(nm, LocalDate.now(), days);
    }
    public SingleJob(String nm, String startDate) {
        this(nm, LocalDate.parse( startDate ), 1);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public LocalDate getStartDate() {
        return start;
    }

    @Override
    public LocalDate getFinishDate() {
        return end;
    }

    @Override
    public String toString() {
        return name +  ": " + start +' '+ end;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o instanceof Job singleJob) {
            return start.equals(singleJob.getStartDate()) &&
                   name.equals(singleJob.getName()) &&
                   end.equals(singleJob.getFinishDate());
        }
        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(start, name, end);
    }
}
