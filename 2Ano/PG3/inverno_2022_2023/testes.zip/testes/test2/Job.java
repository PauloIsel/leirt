package testes.test2;

import java.time.LocalDate;

public interface Job {
    String getName();
    LocalDate getStartDate();
    LocalDate getFinishDate();
}
