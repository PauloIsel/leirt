package testes.test2;


import java.time.LocalDate;
import java.util.*;
import java.util.function.BiPredicate;
import java.util.function.Consumer;

public class Grupo1 {
    public static void forEachIf( Iterable<Job> jobs,
                                  BiPredicate<LocalDate, LocalDate> pred,
                                  Consumer<Job> action) {
        for (Job j : jobs)
            if (pred.test(j.getStartDate(), j.getFinishDate()))
                action.accept(j);
    }

    public static SortedSet<Job> jobsInExecution(Collection<Job> jobs ){
        LocalDate now= LocalDate.now();
        BiPredicate<LocalDate, LocalDate> p = (s, e)-> now.compareTo(s) > 0 && now.compareTo(e)< 0;
        Comparator<Job> cmp= (j1, j2) ->{
            int res = j1.getStartDate().compareTo(j2.getStartDate());
            if ( res != 0 )  return res;
            return j1.getName().compareTo(j2.getName());
        };
        //Comparator<Job> cmp= Comparator.comparing(Job::getStartDate).thenComparing(Job::getName);
        SortedSet<Job> result = new TreeSet<>( cmp );
        forEachIf(jobs, p, j->result.add(j));
        //forEachIf(jobs, p, result::add);
        return result;
    }

    public static Collection<Job> startAfter(SortedMap<LocalDate,Set<Job>> jobsPerDate,
                                             LocalDate minimum) {
        Collection<Job> result= new ArrayList<>();
        for (Map.Entry<LocalDate,Set<Job>> e: jobsPerDate.entrySet()) {
        //for ( var e: jobsPerDate.entrySet() ) {
           if ( e.getKey().compareTo(minimum) > 0 )
                result.addAll(e.getValue());
           else break;
        }
        return result;
    }

    /** FUNÇÂO PARA TESTE - Criar o Map*/

    private static SortedMap<LocalDate,Set<Job>> jobsPerDate( Iterable<Job> seq ) {
        SortedMap<LocalDate,Set<Job>> result = new TreeMap<>(Comparator.reverseOrder());
        seq.forEach( j-> {
            Set<Job> s = result.get( j.getStartDate() );
            if ( s == null ) {
                s= new TreeSet<>(Comparator.comparing(Job::getName));
                result.put(j.getStartDate(), s);
            }
            s.add( j );
        });
        return result;
    }

    public static void main(String[] args) {
        LocalDate now =LocalDate.now();
        LocalDate first = LocalDate.of(now.getYear(),1, 1);
        LocalDate last = LocalDate.of(now.getYear(),12, 31);
        List<Job> l= List.of(
                new SingleJob("a",now.plusDays(-1), 3), // in
                new SingleJob("g",first.plusDays(-1), first.lengthOfYear()+4), //in
                new SingleJob("b",first.plusDays(-1), first.lengthOfYear()+5), //in
                new SingleJob("d",first.plusDays(-2), 2),
                new SingleJob("c",first.plusDays(-2), 1),
                new SingleJob("f",last.plusDays(2), 1), // in after
                new SingleJob("e",last.plusDays(2), 3), // in after
                new SingleJob("g",last.plusDays(1), 1), // in after
                new SingleJob("h",now.plusDays(-3), 6), // in
                new SingleJob("j",now.plusDays(1), 6), // in after
                new SingleJob("i", now.plusDays(1), 1) // in after
        );
        System.out.println( jobsInExecution(l) );
        var m = jobsPerDate( l );
        System.out.println( m );
        System.out.println( startAfter(m,now));
    }

}
