package testes.test2;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.function.BiConsumer;

public class Grupo2 extends JFrame {
    public static int copyJobs(String pathnameIn, LocalDate dt, BiConsumer<String,LocalDate> action)
            throws IOException {
        int count=0;
        try(BufferedReader br = new BufferedReader(new FileReader(pathnameIn))) {
            String line;
            while ((line= br.readLine())!= null) {
                int indexEndName = line.indexOf(':');
                int indexEndStartDate = line.lastIndexOf( ' ');
                String strStartDate= line.substring(indexEndName+1, indexEndStartDate).trim();
                LocalDate start = LocalDate.parse(strStartDate);
                if (start.equals(dt)) {
                    String name = line.substring(0,indexEndName);
                    LocalDate end = LocalDate.parse(line.substring(indexEndStartDate+1).trim());
                    action.accept(name, end);
                    ++count;
                }
            }
        }
        return count;
    }

    public static void copyTodayJobs(String pathnameIn, String pathnameOut) throws IOException{
        try(PrintWriter pw = new PrintWriter( pathnameOut )) {
            copyJobs(pathnameIn, LocalDate.now(), (n, d)-> pw.println( n));
        }
    }

    private final JTextField pathnameField = newJTextField("pathname", 15);
    private final JTextField dateField = newJTextField("date", 8);
    private final JTextArea jobsArea = newJTextArea("jobs");
    public Grupo2() {
        super("Jobs");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        Container cp = getContentPane();
        JPanel north= new JPanel( new BorderLayout());
        north.add(dateField, BorderLayout.WEST);
        north.add(pathnameField);
        cp.add( north, BorderLayout.NORTH);
        cp.add(jobsArea, BorderLayout.CENTER );
        JButton b = new JButton( "list" );
        cp.add( b, BorderLayout.SOUTH );
        b.addActionListener( this::list);
        pack();
    }

    private void list(ActionEvent ae) {
        try{
            jobsArea.setText("");
            BiConsumer<String, LocalDate> action=(n,d)-> jobsArea.append(d + " - " + n + "\n");
            copyJobs(pathnameField.getText(), LocalDate.parse(dateField.getText()),action);
        }
        catch (IOException | DateTimeParseException ex ) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    JTextField newJTextField( String title, int dim) {
        JTextField tf = new JTextField( dim );
        tf.setBorder( new TitledBorder( title ) ); return tf;
    }
    public static JTextArea newJTextArea( String title) {
        JTextArea ta = new JTextArea( 10, 20 );
        ta.setBorder( new TitledBorder( title ) ); return ta;
    }

    public static void main(String[] args) {
        //testCopyTodayJobs();
        new Grupo2().setVisible( true );
    }

    /** FUNÇÂO PARA TESTE do copyTodayJobs*/
    public static void testCopyTodayJobs() {
        try {
            // Se quiserem testar - colocar em jobs um job com a  data corrente
            //Testado em: 2023-01-13
            copyTodayJobs("src/testes/test2/jobs.txt", "src/testes/test2/today.txt");
        }
        catch (Exception e) {
            System.out.println("Error: "+ e.getMessage());
        }

    }
}
