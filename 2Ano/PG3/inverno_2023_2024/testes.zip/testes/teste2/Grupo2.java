package testes.teste2;
import java.io.*;
import java.util.Map;
import java.util.function.BiConsumer;

public class Grupo2 {
    public static void forEachStudent(BufferedReader in, BiConsumer<String, Integer> process)
            throws IOException{
        String line;
        while ((line= in.readLine())!= null){
            int index = line.indexOf(':');
            if (index != -1 ) {
                process.accept(line.substring(0, index).trim(),
                               Integer.parseInt(line.substring(index+1).trim()));
            }
        }
    }
    public static void updateNotes(Map<String, Integer> students,
                                   String filename ) throws IOException {
        try(BufferedReader br = new BufferedReader(new FileReader(filename))) {
            BiConsumer<String, Integer> actualize = (name, note)-> {
                Integer nt = students.get( name );
                if ( nt == null || nt.compareTo(note) <0 )
                    students.put(name, note);
            };
            forEachStudent(br, actualize);
        };
    }
}
