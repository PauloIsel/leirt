package testes.teste2;

import java.util.*;
import java.util.function.Supplier;

public class Grupo1 {

    public static <V, S extends Collection<V>>
    S elementsInRange(Iterable<V> seq, V min, V max, Comparator<V> cmp, Supplier<S> ss){
        S result = ss.get();
        for (V v : seq) {
            if (cmp.compare(v, min) >= 0 &&
                cmp.compare(v, max) <= 0)
                result.add(v);
        }
        return result;
    }

    public static Set<String> wordsStartingWith(List<String> words, char letter){
        String min_max = Character.toString(letter);// or ""+letter
        Comparator<String> cmp = (s1, s2)-> Character.toUpperCase(s1.charAt(0)) -
                                            Character.toUpperCase(s2.charAt(0));
        Supplier<TreeSet<String>> ss = ()-> new TreeSet<>(String::compareToIgnoreCase);
        return elementsInRange( words, min_max, min_max, cmp, ss);
     }

    public static <E> boolean subList(ArrayList<E> l1, ArrayList<E> l2,
                                      Comparator<E> cmp  ){
        if (l2.isEmpty()) return true;
        E first = l2.get(0);
        int i1 = Collections.binarySearch(l1, first, cmp);
        /* OR
        int i1= 0;
        while( i1 < l1.size() &&
               cmp.compare(l1.get(i1),first) < 0) ++i1;
        */
        if (i1 < 0 || l1.size()-i1 < l2.size()) return false;
        for( E e: l2 ) {
            if (cmp.compare(l1.get(i1++), e) != 0)
                    return false;
        }
        return true;
    }


    public static void main(String[] args) {
        List<String> words = Arrays.asList("Agora", "Be", "ana", "D", "E", "F", "G");
        System.out.println(wordsStartingWith(words, 'a'));
        System.out.println(wordsStartingWith(words, 'a').toString().equals("[Agora, ana]"));

        ArrayList<Integer> l1 = new ArrayList<>(List.of(1, 5, 7, 8));
        ArrayList<Integer> l2= new ArrayList<>(List.of(7, 8));
        System.out.println(subList(l1, l2, Comparator.naturalOrder()));
        ArrayList<Integer> l3= new ArrayList<>(List.of(5, 8));
        System.out.println(subList(l1, l3, Comparator.naturalOrder()));

    }

}
