package testes.teste2;

import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.io.*;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by msousa on 6/19/2016.
 */
public class StudentFrame extends JFrame {

    private static JTextField newJTextField( String title ) {
        JTextField tf = new JTextField( 15 );
        tf.setBorder( new TitledBorder( title ) );
        return tf;
    }
    private static JTextArea newJTextArea( String title ) {
        JTextArea ta = new JTextArea( 8, 30 ); ta.setBorder( new TitledBorder( title ) );
        return ta;
    }
    private final JTextField filenameField = newJTextField("filename");
    private final JTextField statusField = newJTextField("status");
    private final JTextArea studentsArea = newJTextArea("students");

    private Map<String,Integer> students= new LinkedHashMap<>();
    public StudentFrame(){
        super("Students" );
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        Container cp= getContentPane();

        JPanel northPanel = new JPanel( new BorderLayout() );
        northPanel.add(filenameField, BorderLayout.CENTER);
        JButton read = new JButton("read");
        read.addActionListener(this::actualize);
        northPanel.add(read, BorderLayout.EAST);

        cp.add( northPanel, BorderLayout.NORTH);
        cp.add(studentsArea);
        cp.add( statusField, BorderLayout.SOUTH);

        pack();
    }
    public void actualize( ActionEvent ev ) {
        try {
            Grupo2.updateNotes(students, filenameField.getText());
            studentsArea.setText("");
            students.forEach((k, v)-> studentsArea.append(k+": "+ v+"\n"));
            statusField.setText("Operation completed successfully");
        } catch ( IOException e ) {
            statusField.setText("Erro: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new StudentFrame().setVisible( true );
    }
}
