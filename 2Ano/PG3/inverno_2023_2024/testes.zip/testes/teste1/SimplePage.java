package testes.teste1;

public class SimplePage extends Page{
    public SimplePage(String title, Paragraph ... pgraphs) {
        super("page", title, pgraphs);
    }
    @Override
    public String renderMenu() {
        return "\t<menu><item>voltar</item></menu>";
    }

    public static void main(String[] args) {
        Paragraph txt = new TextParagraph( "1ª imagem.");
        Paragraph img= new ImageParagraph( "image1.jpg" );
        SimplePage pg= new SimplePage( "1ª página", txt, img );
        System.out.println ( pg.renderMenu() );
        System.out.println( pg.render() );}
}
