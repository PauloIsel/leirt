package testes.teste1;

public abstract class Page {
    private final String tag, title;
    private final Paragraph[] paragraphs;
    protected Page(String tag, String title, Paragraph ... pgraphs) {
        this.tag = tag;
        this.title = title;
        this.paragraphs = pgraphs;
    }
    public final String getTitle() {
        return title;
    }
    public abstract String renderMenu();
    public String render() {
        StringBuilder result = new StringBuilder("<"+ tag+">\n");
        result.append("\t<title>").append(title).append("</title>\n");
        result.append(renderMenu()).append('\n');
        for (Paragraph p : paragraphs) {
            result.append('\t').append(p.getContent()).append('\n');
        }
        result.append("</").append( tag ).append('>');
        return result.toString();
    }
    public Page findFirstPage(String searchedText) {
        if (title.contains(searchedText))
            return this;
        for (Paragraph p : paragraphs) {
            if ( p.containText(searchedText))
                return this;
        }
        return null;
    }
}
