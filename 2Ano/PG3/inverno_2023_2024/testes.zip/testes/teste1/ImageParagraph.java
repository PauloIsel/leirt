package testes.teste1;

public class ImageParagraph implements Paragraph {
    private final String image;
    public ImageParagraph(String image) { this.image = image; }
    @Override
    public String getContent() { return "<img src = \""+image+"\"/>"; }
    @Override
    public boolean containText(String word) { return false; }

    public static void main(String[] args) {
        Paragraph img= new ImageParagraph( "image1.jpg" );
        System.out.println( img.getContent() );
    }
}
