package testes.teste1;

import java.util.ArrayList;
import java.util.List;

public class FolderPage extends Page{
    private final List<Page> pages = new ArrayList<>();
    public FolderPage(int titleId, Paragraph... pgraphs) {
        super("folder", "Pasta "+ titleId, pgraphs);
    }

    public FolderPage addPage(Page page) throws CmsException{
        //if(pages.contains(page)) throw new CmsException(page);
        for (Page p : pages) {
            if (p.getTitle().equals(page.getTitle()))
                throw new CmsException(p);
        }
        this.pages.add(page);
        return this;
    }

    @Override
    public Page findFirstPage(String searchedText) {
        if( super.findFirstPage(searchedText) != null)
            return this;
        for (Page p : pages) {
            Page searchedPage = p.findFirstPage(searchedText);
            if (searchedPage != null)
                return searchedPage;
        }
        return null;
    }

    @Override
    public String renderMenu() {
        StringBuilder result = new StringBuilder("\t<menu>\n");
        for (Page p : pages) {
            result.append("\t\t<item>").append(p.getTitle()).append("</item>\n");
        }
        return result.append("\t</menu>").toString();
    }

    public static void main(String[] args) {

        Page pg1 = new SimplePage( "1ª página", new TextParagraph("1ª imagem"), new ImageParagraph("img1.jpg" ));
        Page pg2 = new SimplePage( "2ª página", new TextParagraph("2ª imagem"), new ImageParagraph("img2.jpg"));

        FolderPage f = new FolderPage( 1, new TextParagraph("Conjunto de páginas." ));
        try {
            f.addPage( pg1 ).addPage( pg2 ).addPage(pg2);
        }
        catch( CmsException e ) {
            System.out.println( e.getMessage() );
        }

        System.out.println( f.render() );

        Page foundPage =  f.findFirstPage("imagem");
        if ( foundPage != null ) System.out.println( foundPage.render() );

    }
}
