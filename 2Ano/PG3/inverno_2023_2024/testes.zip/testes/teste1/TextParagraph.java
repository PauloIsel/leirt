package testes.teste1;

public class TextParagraph implements Paragraph {
    private final String text;
    public TextParagraph(String text) { this.text = text; }
    @Override
    public String getContent() { return "<txt>" + text + "</txt>"; }
    @Override
    public boolean containText(String word) { return text.contains(word); }

    public static void main(String[] args) {
        Paragraph txt = new TextParagraph("1ª imagem.");
        System.out.println(txt.getContent());
    }
}
