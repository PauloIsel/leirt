package testes.teste1;
public interface Paragraph {
    String getContent();
    boolean containText(String word);
}
